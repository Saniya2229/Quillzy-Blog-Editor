export default function Interviews() {
  return <div className="p-6">Interviews Page – Coming Soon</div>;
}
