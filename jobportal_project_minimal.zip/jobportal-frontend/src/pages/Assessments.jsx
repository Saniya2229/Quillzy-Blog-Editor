export default function Assessments() {
  return <div className="p-6">Assessments Page – Coming Soon</div>;
}
