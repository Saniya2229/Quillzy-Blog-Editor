export default function Events() {
  return <div className="p-6">Events Page – Coming Soon</div>;
}
